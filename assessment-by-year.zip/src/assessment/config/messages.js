const messages = {
	error: 'error',
	info: 'info',
	warning: 'warning'
}
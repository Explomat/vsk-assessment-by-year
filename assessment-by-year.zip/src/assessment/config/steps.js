export const uiSteps = {
	first: 'first',
	second: 'second'
}

export const assessmentSteps = {
	first: 1,
	second: 2,
	third: 3,
	fourth: 4
}